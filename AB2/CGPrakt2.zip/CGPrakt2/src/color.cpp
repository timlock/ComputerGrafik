#include "color.h"
#include <assert.h>

Color::Color()
{
  // TODO: add your code
}

Color::Color( float r, float g, float b)
{
	// TODO: add your code
}

Color Color::operator*(const Color& c) const
{
	// TODO: add your code
    return Color(); // dummy (remove)
}

Color Color::operator*(const float Factor) const
{
	// TODO: add your code
	return Color(); // dummy (remove)
}

Color Color::operator+(const Color& c) const
{
	// TODO: add your code
	return Color(); // dummy (remove)
}

Color& Color::operator+=(const Color& c)
{
	// TODO: add your code
	return *this; // dummy (remove)
}