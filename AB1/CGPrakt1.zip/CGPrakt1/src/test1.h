//
//  test1.h
//  SimpleRayTracer
//
//  Created by Philipp Lensing on 19.09.14.
//  Copyright (c) 2014 Philipp Lensing. All rights reserved.
//

#ifndef __SimpleRayTracer__test1__
#define __SimpleRayTracer__test1__

#include <iostream>

class Test1
{
public:
    static void vector();
};

#endif /* defined(__SimpleRayTracer__test1__) */
