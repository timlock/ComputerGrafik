//
//  test2.h
//  SimpleRayTracer
//
//  Created by Philipp Lensing on 19.09.14.
//  Copyright (c) 2014 Philipp Lensing. All rights reserved.
//

#ifndef __SimpleRayTracer__test2__
#define __SimpleRayTracer__test2__

#include <iostream>

class Test2
{
public:
    static void color();
};

#endif /* defined(__SimpleRayTracer__test2__) */
