//
//  test3.h
//  SimpleRayTracer
//
//  Created by Philipp Lensing on 19.09.14.
//  Copyright (c) 2014 Philipp Lensing. All rights reserved.
//

#ifndef __SimpleRayTracer__test3__
#define __SimpleRayTracer__test3__

#include <iostream>

class Test3
{
public:
    static void rgbimage( const char* Directory);
};

#endif /* defined(__SimpleRayTracer__test3__) */
