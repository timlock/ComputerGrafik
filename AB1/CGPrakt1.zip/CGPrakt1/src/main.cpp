#include <iostream>
#include "test1.h"
#include "test2.h"
#include "test3.h"

int main(int argc, const char * argv[]) {
    
	// uncomment the following functions to start the corresponding test routines
	//Test1::vector();
    //Test2::color();
    //Test3::rgbimage("");
    return 0;
}
